import https from 'https';
import crypto from 'crypto';

const nodelessStoreId = process.env.nodelessStoreId;
const nodelessApiKey = process.env.nodelessApiKey;
const nodelessWebhookSecret = process.env.nodelessWebhookSecret;

export async function makeInvoice(satsAmount, orderId) {
  // https://nodeless.io/api/v1/store/{storeid}/invoice

  var payload = {
    "amount": satsAmount, 
    "currency": "SATS", 
    "metadata": {
      "orderId": orderId,
    }
  };
  var options = {
      host: 'nodeless.io',
      port: 443,
      path: '/api/v1/store/' + nodelessStoreId + '/invoice',
      method: 'POST',
      headers: {
          'Authorization': 'Bearer ' + nodelessApiKey,
          'Content-Type': 'application/json',
          'Accept': 'application/json',
      },
  };
  return new Promise((resolve,reject) => {
    const req = https.request(options, res => {
      let buffer = '';
      res.on('data', chunk => { buffer += chunk;});
      res.on('end', () => {
        try {
          resolve(JSON.parse(buffer));
        } catch (err) {
          reject(new Error(err));
        }
      });
    });
    req.on('error', err => {
      reject(new Error(err));
    });
    req.write(JSON.stringify(payload));
    req.end();
  });
}

export async function getNodelessInvoice(id) {
  // https://nodeless.io/api/v1/store/{storeid}/invoice/{id}
  var options = {
      host: 'nodeless.io',
      port: 443,
      path: '/api/v1/store/' + nodelessStoreId + '/invoice/' + id + '/status',
      method: 'GET',
      headers: {
          'Authorization': 'Bearer ' + nodelessApiKey,
          'Content-Type': 'application/json',
          'Accept': 'application/json',
      },
  };
  return new Promise((resolve,reject) => {
    const req = https.request(options, res => {
      let buffer = '';
      res.on('data', chunk => { buffer += chunk;});
      res.on('end', () => {
        try {
          resolve(JSON.parse(buffer));
        } catch (err) {
          reject(new Error(err));
        }
      });
    });
    req.on('error', err => {
      reject(new Error(err));
    });
    req.end();
  });
}

export async function verifySignature(event) {
    let nodelessSig = event.headers["nodeless-signature"];
    if(nodelessSig.length == 0) {
        throw new Error(`nodeless-signature is missing`);
    }
    let hashedresult = crypto.createHmac(
        'sha256', 
        nodelessWebhookSecret,
    ).update(event.body).digest('hex');
    if(hashedresult != nodelessSig) {
        throw new Error(`nodeless-signature contains an unexpected value`);
    }
}

//module.exports = { makeInvoice, getNodelessInvoice, verifySignature };