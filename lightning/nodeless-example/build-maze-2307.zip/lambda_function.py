from scripts.blockhashdungeon import BlockHashDungeonPanel
from decimal import Decimal
import boto3 # for dynamo, s3
import hashlib
import json
import os
import requests
import sys
from urllib3.exceptions import InsecureRequestWarning

s3Client = boto3.client('s3')
s3Bucket = os.environ['s3Bucket']
dynamoClient = boto3.resource('dynamodb')
dynamoTable = os.environ['dynamoTable']

# Layers needed
#   arn:aws:lambda:us-east-1:770693421928:layer:Klayers-p310-Pillow:2
#   arn:aws:lambda:us-east-1:770693421928:layer:Klayers-p310-numpy:2
#   arn:aws:lambda:us-east-1:770693421928:layer:Klayers-p310-requests:3
#   arn:aws:lambda:us-east-1:770693421928:layer:Klayers-p310-boto3:3

def getOrderInfo(orderId):
    # get record from dynamo
    print(f'retrieving {orderId} from table: {dynamoTable}')
    data = dynamoClient.Table(dynamoTable).get_item(
        Key={
            'id': orderId 
        },
        ProjectionExpression='metadata, fulfillment, invoice'
    )
    orderInfo = data['Item']
    return dict(orderInfo)

def getBitcoinBlockhash(blocknumber):
    url = f'https://blockstream.info/api/block-height/{blocknumber}'
    proxies = {}
    headers = {}
    requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)
    output = requests.get(url=url,timeout=2,proxies=proxies,headers=headers).text
    return output

def setFulfillmentStatus(orderId, status, fulfillmentUrl = None):
    data = dynamoClient.Table(dynamoTable).update_item(
        Key={'id':orderId},
        UpdateExpression="SET #f.#s=:fs, #f.#u=:fu",
        ExpressionAttributeNames={
            '#f': 'fulfillment',
            '#s': 'status',
            '#u': 'url',
        },
        ExpressionAttributeValues={
            ':fs': status,
            ':fu': fulfillmentUrl,
        }
    )

def storeOrderImageInS3(filepath, orderId):
    s3Path = f'orders/maze2307/{orderId}.png'
    url = f'https://{s3Bucket}.s3.amazonaws.com/{s3Path}'
    s3Client.upload_file(Filename=filepath, Bucket=s3Bucket, Key=s3Path)
    print(f'uploaded file to s3 bucket. accessible at {url}')
    return url

def lambda_handler(event, context):
    weAreBuilding=False
    orderId = ""
    if "orderId" in event: orderId= event["orderId"]

    try:
        # defaults
        blockheight = 777777
        seedtype = 'blockheight'
        width = 1920
        height = 1080
        usertext = ''
        
        # Load the order
        if "orderId" not in event:
            raise Exception(f'orderId was not passed in event. event looks like {event}')
        orderInfo = getOrderInfo(orderId)
        if "metadata" not in orderInfo:
            raise Exception('metadata was not present on order')
        if "type" not in orderInfo["metadata"]:
            raise Exception('metadata.type was not present on order')
        if orderInfo["metadata"]["type"] != "MAZE2307":
            raise Exception('metadata.type was not expected value for this processor')
        if "invoice" not in orderInfo:
            raise Exception('order has no invoice')
        if "status" not in orderInfo["invoice"]:
            raise Exception('invoice.status was not present on order')
        if orderInfo["invoice"]["status"] != 'paid':
            raise Exception('order status is not paid')
        if "fulfillment" not in orderInfo:
            raise Exception('order has no fulfillment tracking')
        if "status" not in orderInfo["fulfillment"]:
            raise Exception('order has no fulfillment.status tracking')
        fulfillmentStatus = orderInfo["fulfillment"]["status"]
        match fulfillmentStatus:
            case 'pending':
                pass # continue building
            case 'building':
                return {
                    'statusCode': 200,
                    'body': json.dumps("Order is being built by another process")
                }
            case 'done':
                return {
                    'statusCode': 200,
                    'body': json.dumps("Order was completed by another process")
                }
            case other:
                raise Exception(f"unrecognized fulfillment status: {order.fulfillment.status}")

        # Update values based on order
        if "seedtype" in orderInfo["metadata"]:
            seedtype = orderInfo["metadata"]["seedtype"]
        if "width" in orderInfo["metadata"]:
            width = orderInfo["metadata"]["width"]
        if "height" in orderInfo["metadata"]:
            height = orderInfo["metadata"]["height"]
        if "bitcoin" in orderInfo["metadata"]:
            if "blockheight" in orderInfo["metadata"]["bitcoin"]:
                blockheight = orderInfo["metadata"]["bitcoin"]["blockheight"]
        if "usertext" in orderInfo["metadata"]:
            usertext = orderInfo["metadata"]["usertext"]

        # Sanity check the dimensions
        if int(width) > 3840: width = 3840       # 4K limit (8k too much recursion)
        if int(height) > 2160: height = 2160
        if int(width) < 480: width = 480
        if int(height) < 320: height = 320
        
        # Setup the panel
        p = BlockHashDungeonPanel()
        p.watermarkEnabled = False
        p.width = int(width)
        p.height = int(height)
        if seedtype == 'blockheight':
            p.blocknumber = int(blockheight)
            p.blockhash = getBitcoinBlockhash(p.blocknumber)
            p.headerText = f"Blockhash Dungeon|Level {p.blocknumber}"
        if seedtype == 'usertext':
            s = orderInfo["metadata"]["usertext"]
            p.headerText = s
            p.blockhash = hashlib.sha256(s.encode()).hexdigest()
            if(len(s) == 0): p.headerEnabled = 

        # Indicate we are building
        weAreBuilding=True
        setFulfillmentStatus(orderId, 'building')

        # Run it
        p.run()
        
        # Upload file to S3 
        #   from:   (/tmp/blockhashdungeon.png)
        #   to:     {s3bucket}/orderid.png
        url = storeOrderImageInS3('/tmp/blockhashdungeon.png', orderId)

        # Indicate we are done
        setFulfillmentStatus(orderId, 'done', url)
                
    except Exception as err:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        errs = f"Unexpected {err=}, {type(err)=}"
        print(errs)
        # revert as needed
        if weAreBuilding:
            setFulfillmentStatus(orderId, 'pending')
        return {
            'statusCode': 500,
            'body': json.dumps(errs)
        }

    # All good if reached here
    return {
        'statusCode': 200,
        'body': json.dumps(f'Finished! The file is available at {url}')
    }

