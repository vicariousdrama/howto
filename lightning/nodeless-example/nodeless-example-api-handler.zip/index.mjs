import {DynamoDBClient} from "@aws-sdk/client-dynamodb";
import {DynamoDBDocumentClient, PutCommand, UpdateCommand,GetCommand} from "@aws-sdk/lib-dynamodb";
import {LambdaClient, InvokeCommand} from "@aws-sdk/client-lambda";
const dynamoclient = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const lambdaclient = new LambdaClient({region:"us-east-1"});
//const bip39words = import("./bip39words.mjs");
//const nodeless = import("./nodeless.mjs");
import { makeId } from './bip39words.mjs';
import { makeInvoice, getNodelessInvoice, verifySignature } from './nodeless.mjs';
const baseAmount = 7500;


// ---------- FROM CONFIGURATION, SET ENVIRONMENT VARIABLES FOR THE FOLLOWING --
// dynamoTable
// nodelessStoreId
// nodelessApiKey
// nodelessWebhookSecret
// valueCodes
// -----------------------------------------------------------------------------

const dynamoTable = process.env.dynamoTable;

// Used for the MAZE2307 product type.
function getOverageBySize(metadata) {
  let overage = 0;
  let pixelAllotment = 2100000;
  let pixelBlockSize = 500000;
  let pixelBlockOverage = 500;
  let w = 1920;
  let h = 1080;
  if("width" in metadata) { w = metadata.width; }
  if("height" in metadata) { h = metadata.height; }
  let pixelcount = w*h;
  if(pixelcount > pixelAllotment) {
    let blocksOver = Math.ceil((pixelcount - pixelAllotment)/pixelBlockSize);
    overage = blocksOver * pixelBlockOverage;
  }
  return overage;  
}

function calcAmount(baseAmount, metadata, discount) {
  let finalAmount = baseAmount - discount;
  if("type" in metadata) {
    // custom for type of product
    if(metadata.type == "MAZE2307") {
      finalAmount = finalAmount + getOverageBySize(metadata);
    }
  }
  return finalAmount;
}

function getValueCodeDiscount(c) {
  if(c == null ||
    process.env.valueCodes == null ||
    process.env.valueCodes.length == 0) {
    return 0;
  }
  let valueCodes = process.env.valueCodes.split(",");
  let valueCodeIndex = 0;
  let valueCodesLength = valueCodes.length;
  for(valueCodeIndex=0; valueCodeIndex < valueCodesLength; valueCodeIndex ++) {
    let parameters = valueCodes[valueCodeIndex].split(':');
    let code = parameters[0];
    if(code == c && parameters.length > 1) {
      let discountAmount = parameters[1];
      if(parameters.length > 2) {
        let expirationTime = parameters[2];
        if (expirationTime > Date.now()) {
          return discountAmount;
        }
      } else {
        return discountAmount;
      }
    }
  }
  return 0;
}

function invokeBuilder(orderItem) {
  let functionName = null;
  // Map to the function to be called
  if(orderItem.metadata.type == "MAZE2307") {
    functionName = "nodeless-example-build-maze-2307"; 
  }
  if(functionName == null) {
    console.log(`invokeBuilder called, but functionName could not be set from type: ${orderItem.metadata.type}`);
    return;
  }
  
  console.log(`Invoking lambda function: ${functionName}`);
  const input = { 
    FunctionName: functionName,
    InvocationType: "Event",
    LogType: "Tail",
    Payload: JSON.stringify({
      orderId: orderItem.id
    }),
  };
  const command = new InvokeCommand(input);
  const response = lambdaclient.send(command);
  console.log(`response object from invocation: ${JSON.stringify(response)}`);
}

export const handler = async (event, context) => {
  let body;
  let orderId;
  let orderItem;
  let statusCode = 200;
  let currentTimestamp = Date.now();
  
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Headers": 'Content-Type,Authorization',
    "Access-Control-Allow-Methods": '*',      // CORS, allow any
    "Access-Control-Allow-Origin": '*',       // CORS, allow any
  };

  try {
    switch (event.routeKey) {
      case "OPTIONS":                                          // CORS PREFLIGHT
        break;
      case "POST /codes":                               // QUERY VALUE FOR VCODE
        body = {"discount":0};
        let codesData = JSON.parse(event.body);
        let vcode = codesData.vcode;
        body.discount = getValueCodeDiscount(vcode);
        break;
      case "POST /nodeless":                                  // ACCEPT WEBHOOKS
        console.log("RECEIVED webhook call");
        // Authorization check with our secret
        verifySignature(event);
        // Proceed with storage to dynamo
        console.log("- store webhook in dynamo");
        let nodelessJSON = JSON.parse(event.body);
        await dynamoclient.send(
          new PutCommand({
            TableName: dynamoTable,
            Item: {
              id: "NODELESS-WH-" + nodelessJSON.uuid,
              time: currentTimestamp,
              amount: nodelessJSON.amount,
              metadata: nodelessJSON.metadata,
              status: nodelessJSON.status,
              uuid: nodelessJSON.uuid,
            },
          })
        );
        // Update order if status other than new
        if(nodelessJSON.status != "new") {
          console.log("- updatecommand because status is not new");
          orderId = nodelessJSON.metadata.orderId;
          let paidAt = null;
          if(nodelessJSON.status == "paid") {
              paidAt = currentTimestamp;
          }
          await dynamoclient.send(
            new UpdateCommand({
              TableName: dynamoTable,
              Key: {
                "id": orderId,
              },
              UpdateExpression: 'SET #i.#s = :s, updatedAt = :u, paidAt = :p',
              ExpressionAttributeNames: {
                '#i': 'invoice',
                '#s': 'status',
              },
              ExpressionAttributeValues: {
                ':s': nodelessJSON.status,
                ':u': currentTimestamp,
                ':p': paidAt,
              }
            })
          );
          console.log("- get command to get full order");
          orderItem = await dynamoclient.send(
            new GetCommand({
              TableName: dynamoTable,
              Key: {
                id: orderId,
              },
            })
          );
          orderItem = orderItem.Item;
          console.log("- check if paid");
          if((orderItem.invoice.status == "paid") &&
             (orderItem.fulfillment.status == "pending")) {
               console.log("*** Calling invokeBuilder from POST /nodeless");
               invokeBuilder(orderItem);
          }
        }
        body = `Received item ${nodelessJSON.uuid}`;
        break;
      case "POST /orders":                                      // ACCEPT ORDERS
        let ordersJSON = JSON.parse(event.body);
        orderId = "ORDER-" + makeId(currentTimestamp);
        // Determine overall amount
        let discountAmount = getValueCodeDiscount(ordersJSON.discount.vcode);
        let satsAmount = calcAmount(baseAmount, ordersJSON.metadata, discountAmount);
        // Use nodeless to make an invoice in the amount specified
        if(satsAmount > 0) {
          let nodelessInvoice = await makeInvoice(satsAmount, orderId);
          // Assemble item to insert into dynamo
          orderItem = {
            id: orderId,
            createdAt: currentTimestamp,
            updatedAt: currentTimestamp,
            discount: {
              code: ordersJSON.discount.vcode,
              amount: discountAmount,
            },
            invoice: {
              provider: "NODELESS",
              id: nodelessInvoice.data.id,
              satsAmount: nodelessInvoice.data.satsAmount,
              status: nodelessInvoice.data.status,
              createdAt: nodelessInvoice.data.createdAt,
              paidAt: null,
              lightningInvoice: nodelessInvoice.data.lightningInvoice,
              qrCode: nodelessInvoice.data.qrCodes.lightning,
            },
            metadata: ordersJSON.metadata,
            fulfillment: {
              status: "pending",
              url: null,
            },
          };
        } else {
          // The satsAmount is <= 0. Insert as paid (no invoice)
          orderItem = {
            id: orderId,
            createdAt: currentTimestamp,
            updatedAt: currentTimestamp,
            discount: {
              code: ordersJSON.discount.vcode,
              amount: discountAmount,
            },
            invoice: {
              provider: "NONE",
              id: 'not-applicable',
              satsAmount: 0,
              status: 'paid',
              createdAt: currentTimestamp,
              paidAt: currentTimestamp,
              lightningInvoice: null,
              qrCode: null,
            },
            metadata: ordersJSON.metadata,
            fulfillment: {
              status: "pending",
              url: null,
            },
          };
        }
        // Save to dynamo table
        await dynamoclient.send(
          new PutCommand({
            TableName: dynamoTable,
            Item: orderItem,
          })
        );
        // Prep response
        body = {
          "id": orderItem.id, 
          "status": orderItem.invoice.status, 
          "satsAmount": orderItem.invoice.satsAmount,
          "storeInvoiceId": orderItem.invoice.id,
          "lightningInvoice": orderItem.invoice.lightningInvoice,
          "qrCode": orderItem.invoice.qrCode,
          "metadata": orderItem.metadata,
          "fulfillment": orderItem.fulfillment,
        };
        break;
      case "GET /orders/{id}":                             // CHECK ORDER STATUS
      case "GET /orders/{id}/detailed":
        orderId = event.pathParameters.id;
        orderItem = await dynamoclient.send(
          new GetCommand({
            TableName: dynamoTable,
            Key: {
              id: orderId,
            },
          })
        );
        orderItem = orderItem.Item;
        if(event.routeKey == "GET /orders/{id}/detailed") {
          body = {
            "id": orderItem.id, 
            "status": orderItem.invoice.status,
            "satsAmount": orderItem.invoice.satsAmount,
            "lightningInvoice": orderItem.invoice.lightningInvoice,
            "qrCode": orderItem.invoice.qrCode,
            "metadata": orderItem.metadata,
            "fulfillment": orderItem.fulfillment,
          };
        } else {
          // non-detailed contains the bare minimum
          body = {
            "s": orderItem.invoice.status.substr(0,1), 
          };
          if(orderItem.fulfillment.status != "pending") {
            body.fs = orderItem.fulfillment.status.substr(0,1);
          }
          if(orderItem.fulfillment.url != null) {
            body.fu = orderItem.fulfillment.url;
          }
        }
        if(orderItem.invoice.satsAmount == 0 && orderItem.invoice.status == 'paid') {
          console.log("Calling invokeBuilder from GET /orders/{id} for FREE item");
          invokeBuilder(orderItem);
        } else {
          // If last update was more than 10 seconds ago, check for update
          if(orderItem.updatedAt + 10000 < currentTimestamp) {
            let nodelessInvoice = await getNodelessInvoice(orderItem.invoice.id);
            let lastUpdated = orderItem.updatedAt;
            let paidAt = orderItem.invoice.paidAt;
            if ((orderItem.invoice.status != nodelessInvoice.status) &&
                ((nodelessInvoice.status == 'paid')||(nodelessInvoice.status == 'overpaid'))
                ) {
              orderItem.invoice.paidAt = currentTimestamp;
              console.log("Calling invokeBuilder from GET /orders/{id}");
              invokeBuilder(orderItem);
            }
            orderItem.updatedAt = currentTimestamp;
            orderItem.invoice.status = nodelessInvoice.status;
            if(event.routeKey == "GET /orders/{id}/detailed") {
              body.status = nodelessInvoice.status;
            } else {
              body.s = nodelessInvoice.status.substr(0,1);
            }
            await dynamoclient.send(
              new UpdateCommand({
                TableName: dynamoTable,
                Key: {
                  "id": orderItem.id,
                },
                UpdateExpression: 'SET #i.#s = :s, updatedAt = :u, paidAt = :p',
                ConditionExpression: "updatedAt = :t",
                ExpressionAttributeNames: {
                  '#i': 'invoice',
                  '#s': 'status',
                },
                ExpressionAttributeValues: {
                  ':s': orderItem.invoice.status,
                  ':u': currentTimestamp,
                  ':p': paidAt,
                  ':t': lastUpdated,
                }
              })
            );
          }
        }
        break;
      default:
        throw new Error(`Unsupported route: "${event.routeKey}"`);
    }
  } catch (err) {
    statusCode = 400;
    body = err.message;
  } finally {
    body = JSON.stringify(body);
  }
  return {
    statusCode,
    body,
    headers,
  };
};

